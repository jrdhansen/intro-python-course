Jared Hansen, A01439768
CS1400-002, homework 12
due: Thurs, 04/19/2018




#########################
### For problem 11_36 ###
#########################

	Although Andy said that we don't need to show the grid for the turtle, I wanted to see it.
	That being said, the code I used to generate the grid isn't entirely my own. I got code from
the url https://stackoverflow.com/questions/40186594/how-can-i-draw-a-grid-of-squares that did most
of it, and then I supplemented and changed some things to make it look nicer.






#########################
### For problem 11_19 ###
#########################

	I apologize in advance. I started this assignment quite early, and ended up going about it
in a very lengthy way. Andy showed us some tips the day before the assignment was due, but by then
I was so far into my way of doing it that I just stuck it out and got it done rather than starting
over with the quicker/better way he showed us.
	Although my code is not the most efficient way to approach the problem, it does still do all
the right things. I tried to make helpful comments, and format the comments such that they help to 
delineate and provide structure within the code. Sorry if it's hard to read!



















