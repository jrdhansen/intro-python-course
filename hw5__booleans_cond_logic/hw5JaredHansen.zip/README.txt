Jared Hansen, A01439768



Problem 4.4

I wasn't sure how to get both integers to print on the same line. I originally tried the following code:
userSum = eval(input("What is", int1, "+", int2, "?"))
However, this was marked as being syntactically incorrect and I couldn't get it to work.
Thus, I consulted the almighty Google, and StackOverflow came through. Here's the link to the page I used:
https://stackoverflow.com/questions/17529763/printing-variable-and-text-with-input-command
